package com.emerson.eth3.customSOA;

public class ETHCustomSOAExtension {
  
  final static String SUCCESS = "SUCCESS";
  final static String FAILURE = "FAILURE";
  final static String DB_FAILURE = "DB_FAILURE";
  final static String JAVA_FAILURE = "JAVA_ERROR";
  
  public ETHCustomSOAExtension() {
    super();
  }

  /**
   * This Function is used to evaluate ETH DB Procedure response. 
   * If the ResponseCode is 0(ZERO) then it will return 'SUCCESS'.
   * If the ResponseCode is 99 OR (98 with ErrorCodeNumber not starting with SOA or B2B or DB) then it will return 'DB_FAILURE'
   * If the ResponseCode is anything else, it will return 'FAILURE'
   * If there is an exception in the function, it will return 'JAVA_ERROR'
   * @param responseCode - A Number
   * @param errorCodeNumber - A String.
   * @param rollbackFlag - A Number. Not used as of now, but mandatory to pass.
   * @return responseFlag - A String 
   * */
  public static String evaluateDBResponse(int responseCode,
                                          String errorCodeNumber,
                                          int rollbackFlag)

  {
    String errorNumber = (errorCodeNumber==null)?"":errorCodeNumber.trim();
    try{
      if (responseCode == 0)
        return SUCCESS;
      else if (responseCode == 99)
        return DB_FAILURE;
      else if (responseCode == 98 && !errorNumber.equalsIgnoreCase("") && !(errorNumber.startsWith("DB") || errorNumber.startsWith("SOA") || errorNumber.startsWith("B2B")))
        return DB_FAILURE;
      else
        return FAILURE;
    }
    catch(Exception e){
      System.out.println("[ETHCustomSOAExtension][EXCEPTION][evaluateDBResponse] - "+e.getMessage());
      return JAVA_FAILURE;
    }
  }

//public static void main(String[] args) {
// System.out.println("Result - "+evaluateDBResponse(1, "", 1));
//}

}
