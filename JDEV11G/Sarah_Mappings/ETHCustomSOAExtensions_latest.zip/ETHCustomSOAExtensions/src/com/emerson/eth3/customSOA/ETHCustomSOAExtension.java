package com.emerson.eth3.customSOA;

import java.util.*;

import oracle.fabric.common.xml.xpath.*;

public class ETHCustomSOAExtension implements IXPathFunction {
    final String success = "SUCCESS";
    final String failure = "FAILURE";
    final String db_failure = "DB_FAILURE";

    public Object call(IXPathContext context,
                       List funArgs) throws XPathFunctionException {
        int responseCode = (Integer)funArgs.get(0);
        String errorCodeNumber = (String)funArgs.get(1);
        int rollbackFlag = (Integer)funArgs.get(2);
        if (funArgs.size() != 3) {
            throw new XPathFunctionException("This custom XPath function requires exactly three parameters");

        } else {
            if (responseCode == 0)
                return success;
            else if (responseCode == 99 ||
                     (responseCode == 98 && errorCodeNumber != "DB-999999"))
                return db_failure;
            else
                return failure;
        }
    }
}
