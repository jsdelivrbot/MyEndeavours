package VDSTDBINSChannelPartnerPartMap;

import java.sql.Timestamp;

public class VdstChnlpartnerPartNumber {

    private String partNumber;
    private String channelPartnerId;
    private String channelPartnerPartNumber;
    private Timestamp generatedTimestamp;


}
