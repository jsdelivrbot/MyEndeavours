package VDSTDBINSChannelPartnerListStaging;

import java.sql.Timestamp;

public class VdstChnlpartnerMaster1 {

    private String channelPartnerId;
    private String language;
    private String channelPartnerDescription;
    private Timestamp generatedTimestamp;


}
